/* =========================================================
 *  ui.js  ― 画面共通の小さな部品（トースト・モーダル・カード）
 * ========================================================= */
(function () {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const fmt = (n) => Number(n).toLocaleString('ja-JP');
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function toast(msg, type = 'info', ms = 2200) {
    const root = $('#toast-root');
    const el = document.createElement('div');
    el.className = 'toast toast-' + type;
    el.textContent = msg;
    root.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, ms);
  }

  /**
   * modal({ title, body, buttons:[{label, cls, onClick, keepOpen}], cls, closable })
   * body は HTML 文字列 または 要素
   */
  function modal(opts) {
    const root = $('#modal-root');
    const wrap = document.createElement('div');
    wrap.className = 'modal ' + (opts.cls || '');
    wrap.innerHTML = `
      <div class="modal-backdrop"></div>
      <div class="modal-card" role="dialog" aria-modal="true">
        ${opts.title ? `<div class="modal-ribbon"><span class="outline">${opts.title}</span></div>` : ''}
        ${opts.closable !== false ? '<button class="modal-x" aria-label="閉じる">×</button>' : ''}
        <div class="modal-body"></div>
        <div class="modal-buttons"></div>
      </div>`;
    const body = $('.modal-body', wrap);
    if (typeof opts.body === 'string') body.innerHTML = opts.body; else if (opts.body) body.appendChild(opts.body);
    const close = () => {
      if (!wrap.isConnected) return;
      wrap.classList.remove('show');
      setTimeout(() => wrap.remove(), 200);
      if (opts.onClose) opts.onClose();
    };
    (opts.buttons || []).forEach((b) => {
      const btn = document.createElement('button');
      btn.className = 'btn ' + (b.cls || 'btn-gray');
      btn.innerHTML = b.label;
      if (b.disabled) btn.disabled = true;
      btn.addEventListener('click', () => {
        const r = b.onClick ? b.onClick(btn) : undefined;
        if (!b.keepOpen && r !== false) close();
      });
      $('.modal-buttons', wrap).appendChild(btn);
    });
    if (opts.closable !== false) {
      $('.modal-x', wrap).addEventListener('click', close);
      $('.modal-backdrop', wrap).addEventListener('click', close);
    }
    root.appendChild(wrap);
    requestAnimationFrame(() => wrap.classList.add('show'));
    return { el: wrap, body, close };
  }

  /** 装備カード（レアリティ背景＋アイテムの絵） */
  // ❸ の装備のまわりを走る稲妻
  const BOLTS = `<svg class="icard-bolts" viewBox="0 0 100 100" aria-hidden="true">
      <path d="M8 30 L18 22 L14 36 L26 28" /><path d="M92 62 L82 70 L86 56 L74 64" />
      <path d="M62 6 L56 16 L68 14 L60 26" /><path d="M30 94 L38 84 L26 86 L34 74" /></svg>`;
  function itemCard(itemKey, rarity, extra = {}) {
    const lv = extra.lv | 0;
    const mark = DS.config.FUSION.marks[lv] || '';
    return `<div class="icard r-${rarity} ${lv ? 'fz fz' + lv : ''} ${extra.cls || ''}" ${extra.attrs || ''}>
      ${lv >= 3 ? BOLTS : ''}
      ${DS.art.item(itemKey)}
      ${mark ? `<span class="icard-fz">${mark}</span>` : ''}
      ${extra.count > 1 ? `<span class="icard-count">×${extra.count}</span>` : ''}
      ${extra.equipped ? '<span class="icard-eq">E</span>' : ''}
      ${extra.isNew ? '<span class="icard-new">NEW</span>' : ''}
      ${extra.tag ? `<span class="icard-tag">${extra.tag}</span>` : ''}
    </div>`;
  }

  /** キャラのカード（レアリティ背景＋キャラの絵） */
  function charCard(key, extra = {}) {
    const d = DS.config.CHARACTERS[key];
    const rarity = d ? d.rarity : 'common';
    const art = key ? DS.art.charSvg(key) : DS.art.hero(DS.config.PLAYER_COLORS[0]);
    return `<div class="icard ccard r-${key ? rarity : 'none'} ${extra.dim ? 'dim' : ''} ${extra.cls || ''}" ${extra.attrs || ''}>
      ${art}
      ${extra.locked ? '<span class="ccard-lock">？</span>' : ''}
      ${extra.count > 1 ? `<span class="icard-count">×${extra.count}</span>` : ''}
      ${extra.equipped ? '<span class="icard-eq">E</span>' : ''}
      ${extra.isNew ? '<span class="icard-new">NEW</span>' : ''}
    </div>`;
  }

  function rarityLabel(rarity) {
    const r = DS.state.RARITY[rarity];
    return `<span class="rlabel rl-${rarity}">${r.name}</span>`;
  }

  const STAT_NAME = { atk: 'ATK', hp: 'HP', spd: '速度' };
  const sign = (n) => (n > 0 ? '+' : '') + n;

  /** 装備の補正・特殊効果を文章の配列にする */
  function effectLines(itemKey) {
    const d = DS.config.ITEMS[itemKey];
    const out = [];
    if (d.bonus) Object.keys(d.bonus).forEach((k) => out.push({ text: `${STAT_NAME[k]} ${sign(d.bonus[k])}`, good: d.bonus[k] > 0 }));
    if (d.aura) {
      if (d.aura.enemySpd) out.push({ text: `周囲の敵の移動速度 ${sign(d.aura.enemySpd)}`, good: true });
      if (d.aura.enemyAtkSpd) out.push({ text: `周囲の敵の攻撃速度 ${sign(d.aura.enemyAtkSpd)}`, good: true });
    }
    if (d.traits) d.traits.forEach((t) => out.push({ text: t, good: true, tag: true }));
    return out;
  }

  DS.ui = { $, $$, fmt, esc, toast, modal, itemCard, charCard, rarityLabel, effectLines, sign, STAT_NAME };
})();
