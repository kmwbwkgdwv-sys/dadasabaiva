/* =========================================================
 *  screens/lobby.js  ― ロビー画面
 *   ・タブ1「ステージ選択」: ステージを選んでロビーを作成（ホスト）
 *   ・タブ2「ロビーに参加」: ロビーID + パスワードで参加（ゲスト）
 *   ・ルーム画面: 最大4人の待機室。ホストがステージを選んで出撃
 * ========================================================= */
(function () {
  const C = DS.config, S = DS.state, A = DS.art, U = DS.ui;
  const { $, $$, esc, fmt, toast, modal } = U;

  let stageIndex = 0;
  const LOCK = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="12" rx="3" fill="#ffd23d" stroke="#231a3a" stroke-width="2.2"/><path d="M8 10 V7 a4 4 0 0 1 8 0 V10" fill="none" stroke="#231a3a" stroke-width="2.6"/><circle cx="12" cy="15.5" r="2" fill="#231a3a"/></svg>';
  let session = null;
  let roomPassword = '';
  let showPass = false;
  let lastRoomStage = -1;

  const stars = (n) => Array.from({ length: 5 }, (_, i) => `<span class="star ${i < n ? 'on' : ''}">★</span>`).join('');

  function myProfile() {
    const l = S.getLoadout();
    const itemOf = (slot) => { const k = l.equipped[slot]; return k ? k.split(':')[0] : null; };
    return {
      name: l.name, atk: l.atk, hp: l.hp, spd: l.spd,
      weapon: l.weapon ? l.weapon.item : 'kunai',
      weaponRarity: l.weapon ? l.weapon.rarity : 'common',
      weaponLv: (S.parseKey(l.equipped.weapon) || {}).lv || 0,
      belt: itemOf('belt'), boots: itemOf('boots'),
      char: l.char || '',
      look: l.look || '',
    };
  }

  /* ---------------------------------------------------------
   *  ロビー（ホーム）画面
   * --------------------------------------------------------- */
  function render() {
    stageIndex = S.maxStage();   // 一番先の遊べるステージから
    const el = $('#screen-lobby');
    el.innerHTML = `
      <div class="screen-bg lobby-bg">${A.lobbyBg()}</div>
      <div class="screen-scroll">
        <div class="lobby-head">
          <button class="side-btn" id="btn-mission" aria-label="ミッション">
            <span class="side-ic">${A.skillIcon('scroll')}</span><span class="side-label">ミッション</span>
            <b class="badge hidden" id="mission-badge"></b>
          </button>
          <div class="game-logo">
            <span class="logo-main outline">${esc(C.GAME_TITLE).replace(' ', '<br>')}</span>
            <span class="logo-sub">${esc(C.GAME_SUBTITLE)}</span>
          </div>
          <button class="side-btn" id="btn-settings" aria-label="設定">
            <span class="side-ic gear-ic"><svg viewBox="0 0 48 48" aria-hidden="true"><rect x="1.5" y="1.5" width="45" height="45" rx="11" fill="#b7c3d6" stroke="#231a3a" stroke-width="3"/>
              <path d="M24 9 l3 4 5-1 1 5 4 3 -2 4 2 4 -4 3 -1 5 -5 -1 -3 4 -3 -4 -5 1 -1 -5 -4 -3 2 -4 -2 -4 4 -3 1 -5 5 1 Z" fill="#6b7a94" stroke="#231a3a" stroke-width="2.4" stroke-linejoin="round"/>
              <circle cx="24" cy="24" r="6" fill="#e9eef6" stroke="#231a3a" stroke-width="2.4"/></svg></span>
            <span class="side-label">設定</span>
          </button>
        </div>

        <div class="seg" role="tablist">
          <button class="seg-btn active" data-tab="stage" role="tab">ステージ選択</button>
          <button class="seg-btn" data-tab="join" role="tab">ロビーに参加</button>
        </div>

        <div class="panel active" data-panel="stage">
          <div class="stage-card">
            <div class="stage-frame" id="stage-frame">
              <div class="stage-track" id="stage-track">
                ${C.STAGES.map((s) => `<div class="stage-slide">${A.stage(s.key)}</div>`).join('')}
              </div>
              <span class="stage-no outline" id="stage-no"></span>
              <div class="stage-lock hidden" id="stage-lock"><span class="lock-big"></span><b id="stage-lock-text"></b></div>
              <button class="arrow arrow-l" id="stage-prev" aria-label="前のステージ">‹</button>
              <button class="arrow arrow-r" id="stage-next" aria-label="次のステージ">›</button>
            </div>
            <div class="stage-info">
              <h2 class="stage-name" id="stage-name"></h2>
              <div class="stage-diff"><small>難易度</small><span id="stage-stars"></span></div>
              <p class="stage-desc" id="stage-desc"></p>
              <div class="stage-foes" id="stage-foes"></div>
            </div>
            <div class="dots" id="stage-dots">
              ${C.STAGES.map((_, i) => `<button class="dot" data-i="${i}" aria-label="ステージ${i + 1}"></button>`).join('')}
            </div>
          </div>
          <div class="party-hint">
            <span class="party-heads">${C.PLAYER_COLORS.map((c) => `<i style="background:${c}"></i>`).join('')}</span>
            最大${C.MAX_PLAYERS}人で協力プレイ！
          </div>
          <div class="stage-actions">
            <button class="btn btn-blue btn-big" id="btn-solo">ソロで出撃</button>
            <button class="btn btn-yellow btn-big" id="btn-create">ロビーを作成</button>
          </div>
        </div>

        <div class="panel" data-panel="join">
          <div class="join-art">${A.squad()}</div>
          <div class="form-card">
            <label class="field"><span>ロビーID</span>
              <input id="join-id" inputmode="numeric" autocomplete="off" maxlength="7" placeholder="6桁の数字"></label>
            <label class="field"><span>パスワード</span>
              <input id="join-pass" autocomplete="off" maxlength="12" placeholder="ホストに教えてもらおう"></label>
            <button class="btn btn-green btn-big" id="btn-join">ロビーに参加</button>
          </div>
          <p class="note">ホストから「ロビーID」と「パスワード」を教えてもらって入力してください。</p>
        </div>
      </div>`;
    bindHome(el);
    updateStage();
  }

  function bindHome(el) {
    $$('.seg-btn', el).forEach((b) => b.addEventListener('click', () => {
      $$('.seg-btn', el).forEach((x) => x.classList.toggle('active', x === b));
      $$('.panel', el).forEach((p) => p.classList.toggle('active', p.dataset.panel === b.dataset.tab));
    }));
    $('#stage-prev', el).addEventListener('click', () => setStage(stageIndex - 1));
    $('#stage-next', el).addEventListener('click', () => setStage(stageIndex + 1));
    $$('.dot', el).forEach((d) => d.addEventListener('click', () => setStage(+d.dataset.i)));
    enableSwipe($('#stage-frame', el), (dir) => setStage(stageIndex + dir));
    $('#btn-create', el).addEventListener('click', openCreateDialog);
    $('#btn-solo', el).addEventListener('click', startSolo);
    $('#btn-mission', el).addEventListener('click', () => DS.mission.open());
    $('#btn-settings', el).addEventListener('click', () => DS.settings.open());
    updateMissionBadge();
    $('#btn-join', el).addEventListener('click', doJoin);
    $('#join-id', el).addEventListener('input', (e) => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 6); });
    $('#join-pass', el).addEventListener('keydown', (e) => { if (e.key === 'Enter') doJoin(); });
  }

  function enableSwipe(target, onSwipe) {
    let x0 = null, y0 = 0;
    target.addEventListener('pointerdown', (e) => { if (e.target.closest('button')) return; x0 = e.clientX; y0 = e.clientY; });
    target.addEventListener('pointerup', (e) => {
      if (x0 == null) return;
      const dx = e.clientX - x0, dy = e.clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) onSwipe(dx < 0 ? 1 : -1);
    });
    target.addEventListener('pointercancel', () => { x0 = null; });
  }

  function setStage(i) {
    stageIndex = (i + C.STAGES.length) % C.STAGES.length;
    updateStage();
  }

  function updateStage() {
    const s = C.STAGES[stageIndex];
    $('#stage-track').style.transform = `translateX(${-stageIndex * 100}%)`;
    $('#stage-no').textContent = 'STAGE ' + s.no;
    $('#stage-name').textContent = s.name;
    $('#stage-stars').innerHTML = stars(s.diff);
    $('#stage-desc').textContent = s.desc;
    const ro = DS.gameConfig.STAGE_ENEMIES[s.key];
    const boss = DS.gameConfig.BOSSES[ro.boss];
    const mid = ro.midboss || 'bigZombie';
    const foes = ro.spawns.map((x) => x.type).concat(mid);
    // 雑魚敵と中ボスを1行目、ボスは1行下に
    $('#stage-foes').innerHTML = `<small>出現する敵</small>
      <div class="foe-row">${foes.map((t) => `<span class="foe${t === mid ? ' mid' : ''}" title="${DS.gameConfig.ENEMIES[t].name}">${A.enemyIcon(t)}</span>`).join('')}</div>
      <div class="foe-row boss-row"><span class="foe boss" title="${boss.name}">${A.enemyIcon(ro.boss)}</span><span class="foe-boss"><em>BOSS</em>${esc(boss.name)}</span></div>`;
    // 前のステージをクリアしていないステージはロック
    const open = S.isStageOpen(stageIndex);
    $('#stage-lock').classList.toggle('hidden', open);
    if (!open) {
      $('#stage-lock .lock-big').innerHTML = LOCK;
      $('#stage-lock-text').textContent = `STAGE ${stageIndex}「${C.STAGES[stageIndex - 1].name}」をクリアすると解放`;
    }
    $('#btn-solo').disabled = !open; $('#btn-create').disabled = !open;
    $$('#stage-dots .dot').forEach((d, i) => d.classList.toggle('locked', !S.isStageOpen(i)));
    $('#stage-frame').style.setProperty('--accent', s.accent);
    $$('#stage-dots .dot').forEach((d, i) => d.classList.toggle('active', i === stageIndex));
  }

  function updateMissionBadge() {
    const b = $('#mission-badge');
    if (!b) return;
    const n = S.missionStatus().claimable;
    b.textContent = n;
    b.classList.toggle('hidden', !n);
  }

  /* ---------- ソロで出撃（通信なし） ---------- */
  function startSolo() {
    if (DS.battle.active) return;
    if (!S.isStageOpen(stageIndex)) { toast('前のステージをクリアすると遊べます', 'error'); return; }
    const me = Object.assign({ id: 'solo', slot: 0, isHost: true }, myProfile());
    DS.battle.start({ stageIndex, members: [me], selfId: 'solo', isHost: true, session: null, onExit: () => {} });
  }

  /* ---------- ロビー作成 ---------- */
  function openCreateDialog() {
    if (!S.isStageOpen(stageIndex)) { toast('前のステージをクリアすると遊べます', 'error'); return; }
    const s = C.STAGES[stageIndex];
    const pass = String(Math.floor(1000 + Math.random() * 9000));
    const m = modal({
      title: 'ロビーを作成',
      body: `
        <div class="create-stage">${A.stage(s.key)}<span class="outline">STAGE ${s.no}　${esc(s.name)}</span></div>
        <label class="field"><span>パスワード（4〜12文字）</span>
          <input id="create-pass" autocomplete="off" maxlength="12" value="${pass}"></label>
        <p class="note dark">参加する仲間に「ロビーID」と「パスワード」を伝えてください。ロビーIDは作成後に表示されます。</p>`,
      buttons: [
        { label: 'やめる', cls: 'btn-gray' },
        {
          label: '作成する', cls: 'btn-yellow', keepOpen: true,
          onClick: async (btn) => {
            const pw = $('#create-pass', m.el).value.trim();
            if (pw.length < 4) { toast('パスワードは4文字以上にしてください', 'error'); return; }
            btn.disabled = true; btn.textContent = '作成中…';
            try {
              const sess = await DS.net.createLobby({ password: pw, stage: stageIndex, profile: myProfile(), maxStage: S.maxStage() });
              m.close();
              if (DS.net.fellBackToLocal) toast('オンラインに接続できないため、ローカルモードで作成しました', 'info', 3500);
              openRoom(sess, pw);
            } catch (e) {
              toast(DS.net.message(e.code), 'error', 3200);
              btn.disabled = false; btn.textContent = '作成する';
            }
          },
        },
      ],
    });
  }

  /* ---------- ロビー参加 ---------- */
  let joining = false;
  async function doJoin() {
    if (joining) return;
    const id = $('#join-id').value.replace(/\D/g, '');
    const pw = $('#join-pass').value.trim();
    if (id.length !== 6) { toast(DS.net.message('badid'), 'error'); return; }
    if (!pw) { toast('パスワードを入力してください', 'error'); return; }
    const btn = $('#btn-join');
    joining = true; btn.disabled = true; btn.textContent = '接続中…';
    try {
      const sess = await DS.net.joinLobby({ lobbyId: id, password: pw, profile: myProfile() });
      $('#join-pass').value = '';
      openRoom(sess, pw);
    } catch (e) {
      toast(DS.net.message(e.code), 'error', 3200);
    } finally {
      joining = false; btn.disabled = false; btn.textContent = 'ロビーに参加';
    }
  }

  /* ---------------------------------------------------------
   *  ルーム画面（待機室）
   * --------------------------------------------------------- */
  function openRoom(sess, password) {
    session = sess;
    roomPassword = password;
    showPass = false;
    lastRoomStage = -1;
    const room = $('#room');
    room.innerHTML = `
      <div class="room-bg" id="room-bg"></div>
      <div class="room-scroll">
        <header class="room-head">
          <button class="btn btn-red btn-small" id="room-leave">退出</button>
          <h2 class="room-title outline">ロビー</h2>
          <span class="net-chip" id="net-chip"></span>
        </header>
        <div class="cred">
          <div class="cred-item"><small>ロビーID</small><b id="room-id"></b></div>
          <div class="cred-item"><small>パスワード</small>
            <span class="cred-row"><b id="room-pass"></b><button class="mini-btn" id="toggle-pass">表示</button></span></div>
          <button class="mini-btn copy" id="copy-cred">コピー</button>
        </div>
        <div class="room-stage" id="room-stage">
          <div class="room-stage-art" id="room-stage-art"></div>
          <button class="arrow arrow-l" id="room-prev" aria-label="前のステージ">‹</button>
          <button class="arrow arrow-r" id="room-next" aria-label="次のステージ">›</button>
          <div class="room-stage-label">
            <span class="stage-chip" id="room-stage-no"></span>
            <b id="room-stage-name"></b>
            <span class="room-stars" id="room-stars"></span>
          </div>
        </div>
        <p class="room-note" id="room-note"></p>
        <span class="room-diff" id="room-diff"></span>
        <div class="slots" id="slots"></div>
      </div>
      <div class="room-foot">
        <p class="room-status" id="room-status"></p>
        <button class="btn btn-big" id="room-action"></button>
      </div>`;
    room.classList.remove('hidden');
    requestAnimationFrame(() => room.classList.add('show'));

    $('#room-leave').addEventListener('click', confirmLeave);
    $('#toggle-pass').addEventListener('click', () => { showPass = !showPass; renderRoom(); });
    $('#copy-cred').addEventListener('click', copyCredentials);
    $('#room-prev').addEventListener('click', () => session.setStage(session.state.stage - 1));
    $('#room-next').addEventListener('click', () => session.setStage(session.state.stage + 1));
    enableSwipe($('#room-stage'), (dir) => { if (session.isHost) session.setStage(session.state.stage + dir); });
    $('#room-action').addEventListener('click', onAction);

    sess.on('state', () => renderRoom());
    sess.on('joined', (m) => toast(`${m.name} が参加しました`, 'good'));
    sess.on('left', (m) => toast(`${m.name} が退出しました`));
    sess.on('start', (st) => showStart(st));
    sess.on('closed', (reason) => {
      if (DS.battle && DS.battle.active) DS.battle.stop();
      closeRoom();
      modal({ title: 'ロビー', body: `<p class="center">${esc(DS.net.message(reason))}</p>`, buttons: [{ label: 'OK', cls: 'btn-blue' }] });
    });
    window.addEventListener('pagehide', onPageHide);
    renderRoom();
  }

  function onPageHide() { if (session) session.leave(); }

  function closeRoom() {
    const room = $('#room');
    room.classList.remove('show');
    setTimeout(() => { if (!session) { room.classList.add('hidden'); room.innerHTML = ''; } }, 250);
    session = null;
    window.removeEventListener('pagehide', onPageHide);
  }

  function confirmLeave() {
    if (!session) return;
    const host = session.isHost;
    modal({
      title: host ? 'ロビーを解散' : 'ロビーを退出',
      body: `<p class="center">${host ? 'ロビーを解散しますか？<br>参加中の仲間も退出になります。' : 'ロビーから退出しますか？'}</p>`,
      buttons: [
        { label: 'もどる', cls: 'btn-gray' },
        { label: host ? '解散する' : '退出する', cls: 'btn-red', onClick: () => { if (session) session.leave(); closeRoom(); } },
      ],
    });
  }

  function copyCredentials() {
    const st = session.state;
    const text = `【${C.GAME_TITLE}】ロビーに参加してね！\nロビーID: ${st.lobbyId}\nパスワード: ${roomPassword}`;
    const done = () => toast('ロビーIDとパスワードをコピーしました', 'good');
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done));
    } else fallbackCopy(text, done);
  }
  function fallbackCopy(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { toast('コピーできませんでした', 'error'); }
    ta.remove();
  }

  function onAction() {
    if (!session) return;
    if (session.isHost) {
      if (!session.start()) toast('全員の準備OKを待っています', 'error');
    } else {
      const me = session.me;
      session.setReady(!(me && me.ready));
    }
  }

  function renderRoom() {
    if (!session || !session.state) return;
    const st = session.state;
    const host = session.isHost;
    const stg = C.STAGES[st.stage];
    const waiting = st.status === 'waiting';

    $('#room-id').textContent = st.lobbyId.slice(0, 3) + ' ' + st.lobbyId.slice(3);
    $('#room-pass').textContent = showPass ? roomPassword : '•'.repeat(Math.max(4, roomPassword.length));
    $('#toggle-pass').textContent = showPass ? '隠す' : '表示';
    $('#net-chip').textContent = st.transport === 'online' ? 'オンライン' : 'ローカル';
    $('#net-chip').classList.toggle('local', st.transport !== 'online');

    if (lastRoomStage !== st.stage) {
      $('#room-stage-art').innerHTML = A.stage(stg.key);
      $('#room-bg').style.setProperty('--accent', stg.accent);
      lastRoomStage = st.stage;
    }
    $('#room-stage-no').textContent = 'STAGE ' + stg.no;
    $('#room-stage-name').textContent = stg.name;
    $('#room-stars').innerHTML = stars(stg.diff);
    $('#room-stage').classList.toggle('can-pick', host && waiting);
    $('#room-note').textContent = host ? 'あなたはホストです。ステージを選んで出撃しよう！' : 'ステージはホストが選びます。';
    const party = st.members.length > 1, GCD = DS.gameConfig.DIFFICULTY;
    $('#room-diff').textContent = party ? `パーティー討伐：難易度×${GCD.party}（敵の体力${GCD.party}倍）` : `1人討伐：難易度×${GCD.solo}`;
    $('#room-diff').classList.toggle('solo', !party);

    // 4人分の枠
    $('#slots').innerHTML = [0, 1, 2, 3].map((i) => {
      const m = st.members.find((x) => x.slot === i);
      const color = C.PLAYER_COLORS[i];
      if (!m) {
        return `<div class="slot empty" style="--pc:${color}">
          <div class="slot-top">P${i + 1}</div>
          <div class="slot-q">?</div>
          <div class="slot-name">募集中…</div>
        </div>`;
      }
      const isMe = m.id === session.selfId;
      const badge = m.isHost ? '<span class="slot-badge host">HOST</span>'
        : m.ready ? '<span class="slot-badge ready">準備OK</span>' : '<span class="slot-badge wait">準備中</span>';
      return `<div class="slot ${isMe ? 'me' : ''}" style="--pc:${color}">
        <div class="slot-top">P${i + 1}${m.isHost ? A.crown() : ''}${isMe ? '<em>あなた</em>' : ''}</div>
        <div class="slot-hero">${m.look ? A.charSvg(m.look) : A.hero(color)}</div>
        <div class="slot-name">${esc(m.name)}</div>
        <div class="slot-stats"><span><b class="c-atk">ATK</b>${fmt(m.atk)}</span><span><b class="c-hp">HP</b>${fmt(m.hp)}</span></div>
        <div class="slot-weapon">${U.itemCard(m.weapon, m.weaponRarity, { cls: 'mini', lv: m.weaponLv })}</div>
        ${badge}
      </div>`;
    }).join('');

    // 下のボタン
    const btn = $('#room-action');
    const status = $('#room-status');
    const guests = st.members.filter((x) => !x.isHost);
    const readyN = guests.filter((x) => x.ready).length;
    btn.className = 'btn btn-big';
    if (!waiting) {
      btn.classList.add('btn-gray'); btn.disabled = true; btn.textContent = '出撃中…';
      status.textContent = '';
    } else if (host) {
      btn.classList.add('btn-yellow');
      btn.disabled = !session.canStart();
      btn.textContent = `出撃！（${st.members.length}/${C.MAX_PLAYERS}人）`;
      status.textContent = guests.length === 0
        ? '1人でも出撃できます。仲間を呼ぶなら ID とパスワードを伝えよう'
        : readyN === guests.length ? '全員準備OK！出撃できます' : `仲間の準備を待っています（${readyN}/${guests.length}）`;
    } else {
      const me = session.me;
      btn.disabled = false;
      if (me && me.ready) { btn.classList.add('btn-gray'); btn.textContent = '準備OKを取り消す'; status.textContent = 'ホストの出撃を待っています…'; }
      else { btn.classList.add('btn-green'); btn.textContent = '準備OK！'; status.textContent = '準備ができたらボタンを押してね'; }
    }
  }

  /* ---------- 出撃演出（ゲーム本編はここから呼び出す） ---------- */
  function showStart(st) {
    const room = $('#room');
    const old = $('.start-ov', room);
    if (old) old.remove();
    const stg = C.STAGES[st.stage];
    const ov = document.createElement('div');
    ov.className = 'start-ov';
    ov.innerHTML = `
      <div class="start-art">${A.stage(stg.key)}</div>
      <div class="start-title outline">STAGE ${stg.no}<br>${esc(stg.name)}</div>
      <div class="start-faces">${st.members.map((m) => `<span class="start-face" style="--pc:${C.PLAYER_COLORS[m.slot]}">${m.look ? A.charFace(m.look) : A.heroFace(C.PLAYER_COLORS[m.slot])}<small>${esc(m.name)}</small></span>`).join('')}</div>
      <div class="start-count outline" id="start-count">3</div>
      <div class="start-msg hidden" id="start-msg">
        <p>ゲーム本編は次のステップで実装します。</p>
        <button class="btn btn-blue" id="start-back">ロビーに戻る</button>
      </div>`;
    room.appendChild(ov);
    const sess = session;
    let n = 3;
    const cnt = $('#start-count', ov);
    const tick = setInterval(() => {
      n--;
      if (n > 0) { cnt.textContent = n; cnt.classList.remove('pop'); void cnt.offsetWidth; cnt.classList.add('pop'); return; }
      clearInterval(tick);
      cnt.textContent = 'GO!';
      setTimeout(() => {
        const payload = {
          stage: stg, stageIndex: st.stage, members: st.members, selfId: sess && sess.selfId, isHost: sess && sess.isHost, session: sess, loadout: S.getLoadout(),
          // バトルが終わってロビーに戻るとき
          onExit: () => { ov.remove(); if (sess && sess.isHost && !sess.ended) sess.endGame(); },
          // バトル中にロビーから抜けるとき（ゲスト）
          onLeave: () => { if (DS.battle) DS.battle.stop(); if (sess) sess.leave(); closeRoom(); },
        };
        if (DS.hooks && typeof DS.hooks.onGameStart === 'function' && DS.hooks.onGameStart(payload) === true) return;
        cnt.classList.add('hidden');
        $('#start-msg', ov).classList.remove('hidden');
      }, 600);
    }, 800);
    $('#start-back', ov).addEventListener('click', () => {
      ov.remove();
      if (sess && sess.isHost) sess.endGame();
    });
  }

  DS.lobby = { render, updateMissionBadge, refreshStage: () => { if ($('#stage-track')) { stageIndex = Math.min(stageIndex, C.STAGES.length - 1); updateStage(); } }, goToStage: (i) => { if ($('#stage-track')) { stageIndex = i; updateStage(); } }, get session() { return session; } };
})();
