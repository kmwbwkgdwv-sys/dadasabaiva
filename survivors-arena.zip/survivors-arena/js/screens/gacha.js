/* =========================================================
 *  screens/gacha.js  ― 装備ガチャ / キャラガチャ
 *   1回 3,000 コイン / 10回 30,000 コイン
 *   確率: コモン60% アンコモン25% レア11.5% エピック3% レジェンド0.5%（どちらも同じ）
 *   レアリティを抽選したあと、その中から等確率で1つ選びます。
 *   キャラガチャはステージ2をクリアすると解放されます。
 * ========================================================= */
(function () {
  const C = DS.config, S = DS.state, A = DS.art, U = DS.ui;
  const { $, $$, esc, fmt, toast, modal } = U;
  const ITEM_KEYS = Object.keys(C.ITEMS);
  const CHAR_KEYS = Object.keys(C.CHARACTERS);
  const TOTAL_WEIGHT = C.RARITIES.reduce((a, r) => a + r.weight, 0);
  // ガチャ画面での並び順（上から 武器 → 防具 → ベルト → 靴）
  const ORDERED_ITEMS = C.GACHA_ORDER.flatMap((slot) => ITEM_KEYS.filter((k) => C.ITEMS[k].slot === slot));
  const sfx = (n) => { if (DS.sound) DS.sound.play(n); };
  let mode = 'item';
  const TICKET = '<svg viewBox="0 0 32 22" aria-hidden="true"><path d="M2 3 H30 V8 a3 3 0 0 0 0 6 V19 H2 V14 a3 3 0 0 0 0 -6 Z" fill="#ff7ad9" stroke="#231a3a" stroke-width="2" stroke-linejoin="round"/><path d="M11 4 V18" stroke="#231a3a" stroke-width="1.6" stroke-dasharray="2 2"/><path d="M19 7 l1.5 3 3.2.4 -2.4 2.2 .7 3.2 -3 -1.7 -3 1.7 .7 -3.2 -2.4 -2.2 3.2 -.4 Z" fill="#fff6c2"/></svg>';
  const LOCK = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="12" rx="3" fill="#ffd23d" stroke="#231a3a" stroke-width="2.2"/><path d="M8 10 V7 a4 4 0 0 1 8 0 V10" fill="none" stroke="#231a3a" stroke-width="2.6"/><circle cx="12" cy="15.5" r="2" fill="#231a3a"/></svg>';

  // 0以上1未満の乱数（使えれば crypto を使う）
  function rand() {
    if (window.crypto && crypto.getRandomValues) return crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296;
    return Math.random();
  }
  /** limited = true のときはエピック・レジェンドの分がレアになる（ステージ1クリア前） */
  function rollRarity(limited) {
    let r = rand() * TOTAL_WEIGHT, out = C.RARITIES[0].key;
    for (const x of C.RARITIES) { if (r < x.weight) { out = x.key; break; } r -= x.weight; }
    if (limited && !C.EARLY_RARITIES.includes(out)) out = C.EARLY_RARITIES[C.EARLY_RARITIES.length - 1];
    return out;
  }
  /** 今のガチャの確率表（limited のときはレアに合算） */
  function rateTable(limited) {
    const rows = C.RARITIES.map((r) => ({ key: r.key, name: r.name, w: r.weight, open: true }));
    if (limited) {
      const top = rows.find((r) => r.key === C.EARLY_RARITIES[C.EARLY_RARITIES.length - 1]);
      rows.forEach((r) => { if (!C.EARLY_RARITIES.includes(r.key)) { top.w += r.w; r.w = 0; r.open = false; } });
    }
    rows.forEach((r) => { r.pct = +(r.w / TOTAL_WEIGHT * 100).toFixed(2); r.label = r.open ? r.pct + '%' : '—'; });
    return rows;
  }
  const limitedNow = () => !S.fullRarity();
  const rollItem = () => ITEM_KEYS[Math.floor(rand() * ITEM_KEYS.length)];
  function rollChar(rarity) {
    const pool = CHAR_KEYS.filter((k) => C.CHARACTERS[k].rarity === rarity);
    return pool[Math.floor(rand() * pool.length)];
  }
  const costOf = (n) => (n === 1 ? C.GACHA.singleCost : C.GACHA.multiCost);

  /** 装備ガチャを n 回引く。ticket=true ならチケットを使う。引けなければ null */
  function pull(n, ticket) {
    if (ticket ? !S.useTicket('item10') : !S.spendCoins(costOf(n))) return null;
    const limited = limitedNow();
    const results = [];
    for (let i = 0; i < n; i++) {
      const item = rollItem(), rarity = rollRarity(limited);
      results.push({ kind: 'item', item, rarity, isNew: S.addItem(item, rarity) });
    }
    S.data.totalPulls += n;
    S.persist();
    return results;
  }
  /** キャラガチャを n 回引く */
  function pullChar(n, ticket) {
    if (!S.charGachaUnlocked()) return null;
    if (ticket ? !S.useTicket('char10') : !S.spendCoins(costOf(n))) return null;
    const results = [];
    for (let i = 0; i < n; i++) {
      const rarity = rollRarity(), key = rollChar(rarity);
      results.push({ kind: 'char', key, rarity, isNew: S.addChar(key) });
    }
    S.persist();
    return results;
  }

  /* ---------- 画面 ---------- */
  function render() {
    const el = $('#screen-gacha');
    el.innerHTML = `
      <div class="screen-bg gacha-bg"></div>
      <div class="screen-scroll">
        <div class="seg gacha-seg" role="tablist">
          <button class="seg-btn" data-mode="item" role="tab">装備ガチャ</button>
          <button class="seg-btn" data-mode="char" role="tab">キャラガチャ<i class="lock-ic" id="char-lock-ic">${LOCK}</i></button>
        </div>
        <div id="gacha-panel"></div>
      </div>`;
    $$('.gacha-seg .seg-btn', el).forEach((b) => b.addEventListener('click', () => { mode = b.dataset.mode; drawPanel(); }));
    drawPanel();
  }

  function drawPanel() {
    const panel = $('#gacha-panel');
    if (!panel) return;
    $$('.gacha-seg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
    const isChar = mode === 'char';
    const locked = isChar && !S.charGachaUnlocked();
    const limited = !isChar && limitedNow();
    const showRar = limited ? ['rare', 'uncommon', 'common'] : ['legend', 'epic', 'rare', 'uncommon'];
    const lineup = isChar
      ? `<div class="gacha-lineup chars">${CHAR_KEYS.map((k) => U.charCard(k, { cls: 'mini' })).join('')}</div>`
      : `<div class="gacha-rows">${C.GACHA_ORDER.map((slot, si) => {
          const keys = ORDERED_ITEMS.filter((k) => C.ITEMS[k].slot === slot);
          return `<div class="gacha-row"><span class="gacha-row-label">${C.SLOTS.find((x) => x.key === slot).name}</span>
            <div class="gacha-row-items">${keys.map((k, i) => U.itemCard(k, showRar[(si + i) % showRar.length], { cls: 'mini' })).join('')}</div></div>`;
        }).join('')}</div>`;
    const tKey = isChar ? 'char10' : 'item10';
    const tickets = S.data.tickets[tKey] || 0;
    const rates = rateTable(limited);
    panel.innerHTML = `
      <div class="gacha-banner ${isChar ? 'char' : ''} ${locked ? 'locked' : ''}">
        <div class="gacha-head">
          <span class="gacha-title outline">${isChar ? 'キャラガチャ' : '装備ガチャ'}</span>
          <span class="gacha-sub">${isChar ? 'レア以上は特殊スキル付き！レアリティが高いほど強い' : '武器・防具・ベルト・靴が当たる！'}</span>
        </div>
        ${isChar ? `<div class="gacha-chars">${['sword', 'freya', 'gunman'].map((k) => `<span>${A.charSvg(k)}</span>`).join('')}</div>` : `<div class="gacha-chest">${A.chest()}</div>`}
        ${lineup}
        ${locked ? `<div class="gacha-lock"><span class="lock-big">${LOCK}</span><b>ステージ${C.CHAR_TICKET_STAGE + 1}「${esc(C.STAGES[C.CHAR_TICKET_STAGE].name)}」をクリアすると解放</b><small>クリアするとキャラガチャ10連無料チケットがもらえます。<br>キャラの見た目は「装備」画面からいつでも変えられます。</small></div>` : ''}
      </div>
      <div class="rate-strip">
        ${rates.map((r) => `<span class="rate rt-${r.key} ${r.open ? '' : 'off'}"><b>${r.name}</b>${r.label}</span>`).join('')}
      </div>
      ${limited ? `<p class="rate-note">ステージ1をクリアするまでは、コモン・アンコモン・レアだけが出ます</p>` : ''}
      <button class="link-btn" id="btn-rates">提供割合・${isChar ? 'キャラ' : 'ステータス'}の詳細</button>
      <div class="gacha-buttons">
        <button class="btn btn-blue gacha-btn" data-n="1" ${locked ? 'disabled' : ''}>
          <span class="gb-label">1回引く</span><span class="gb-cost">${A.coin()}${fmt(C.GACHA.singleCost)}</span></button>
        ${tickets > 0 && !locked
          ? `<button class="btn btn-pink gacha-btn ticket" data-n="${C.GACHA.multiCount}" data-ticket="1">
              <span class="gb-label">${C.GACHA.multiCount}回引く</span><span class="gb-cost"><i class="tk">${TICKET}</i>無料チケット ×${tickets}</span></button>`
          : `<button class="btn btn-yellow gacha-btn" data-n="${C.GACHA.multiCount}" ${locked ? 'disabled' : ''}>
              <span class="gb-label">${C.GACHA.multiCount}回引く</span><span class="gb-cost">${A.coin()}${fmt(C.GACHA.multiCost)}</span></button>`}
      </div>`;
    $$('.gacha-btn', panel).forEach((b) => b.addEventListener('click', () => run(+b.dataset.n, !!b.dataset.ticket)));
    $('#btn-rates', panel).addEventListener('click', isChar ? showCharRates : showRates);
    update();
  }

  let lastKey = '';
  function update() {
    const coins = S.data.coins;
    $$('#screen-gacha .gacha-btn').forEach((b) => b.classList.toggle('short', !b.dataset.ticket && coins < costOf(+b.dataset.n)));
    const ic = $('#char-lock-ic');
    if (ic) ic.classList.toggle('hidden', S.charGachaUnlocked());
    // チケット・解放の状態が変わったら描き直す
    const key = [S.charGachaUnlocked(), S.fullRarity(), S.data.tickets.item10, S.data.tickets.char10].join();
    if (key !== lastKey) { lastKey = key; drawPanel(); }
  }
  function setMode(m) { mode = m; drawPanel(); }

  const perOne = (w, n) => (w / TOTAL_WEIGHT * 100 / n).toFixed(4).replace(/0+$/, '').replace(/\.$/, '') + '%';

  function showRates() {
    modal({
      title: '提供割合',
      cls: 'modal-wide',
      body: `
        <table class="rate-table">
          <thead><tr><th>レアリティ</th><th>確率</th><th>上昇値</th><th>1種あたり</th></tr></thead>
          <tbody>${rateTable(limitedNow()).map((r) => `<tr><td>${U.rarityLabel(r.key)}</td><td><b>${r.open ? r.pct + '%' : '—'}</b></td><td>+${C.RARITIES.find((x) => x.key === r.key).atk}</td><td>${r.open ? perOne(r.w, ITEM_KEYS.length) : '—'}</td></tr>`).join('')}</tbody>
        </table>
        ${limitedNow() ? '<p class="note dark">ステージ1をクリアするまでは、エピック・レジェンドの分がレアになります。クリア後はコモン60%・アンコモン25%・レア11.5%・エピック3%・レジェンド0.5%です。</p>' : ''}
        <p class="note dark">武器・ベルトは <b class="c-atk">ATK</b>、防具・靴は <b class="c-hp">HP</b> が上昇値ぶん上がります。見た目と名前はレアリティ共通で、背景の色だけが変わります。各レアリティの中で ${ITEM_KEYS.length} 種類の装備が同じ確率で出ます。同じ装備を${C.FUSION.need}つ集めると合成できます（${C.FUSION.marks.slice(1).map((m, i) => `${m} ${C.FUSION.mult[i + 1]}倍`).join('・')}）。</p>
        <h3 class="sub-head">装備の種類と効果</h3>
        <div class="item-list">${ORDERED_ITEMS.map((k) => {
          const d = C.ITEMS[k];
          const slot = C.SLOTS.find((s) => s.key === d.slot);
          return `<div class="item-row">${U.itemCard(k, 'common', { cls: 'mini' })}
            <div><b>${esc(d.name)}</b> <span class="slot-tag">${slot.name}</span>
            <div class="effs">${U.effectLines(k).map((e) => `<span class="eff ${e.good ? 'good' : 'bad'}">${esc(e.text)}</span>`).join('')}</div>
            <small>${esc(d.desc)}</small></div></div>`;
        }).join('')}</div>`,
      buttons: [{ label: 'とじる', cls: 'btn-blue' }],
    });
  }

  function showCharRates() {
    modal({
      title: 'キャラガチャ',
      cls: 'modal-wide',
      body: `
        <table class="rate-table">
          <thead><tr><th>レアリティ</th><th>出る確率</th><th>1体あたり</th><th>ATK・HPの増加</th></tr></thead>
          <tbody>${C.RARITIES.map((r) => `<tr><td>${U.rarityLabel(r.key)}</td><td><b>${r.rate}</b></td><td>${perOne(r.weight, CHAR_KEYS.filter((k) => C.CHARACTERS[k].rarity === r.key).length)}</td><td>×${C.CHAR_MULT[r.key]}</td></tr>`).join('')}</tbody>
        </table>
        <p class="note dark">「出る確率」がガチャから出る確率です。「ATK・HPの増加」は、そのキャラを設定したときに自分の ATK と HP にかかる倍率です（×1.2 なら1.2倍）。キャラは「装備」画面で設定でき、見た目とスキルは別々に選べます。レア以上は試合中に使える特殊スキルを持っています。</p>
        <h3 class="sub-head">キャラ一覧</h3>
        <div class="item-list">${CHAR_KEYS.map((k) => {
          const d = C.CHARACTERS[k];
          return `<div class="item-row">${U.charCard(k, { cls: 'mini' })}
            <div><b>${esc(d.name)}</b> ${U.rarityLabel(d.rarity)} <span class="slot-tag">ATK・HP ×${C.CHAR_MULT[d.rarity]}</span>
            ${d.skill ? `<div class="effs"><span class="eff skill">${esc(d.skill.name)}：${esc(d.skill.desc)}</span></div>` : ''}
            <small>${esc(d.desc)}</small></div></div>`;
        }).join('')}</div>`,
      buttons: [{ label: 'とじる', cls: 'btn-blue' }],
    });
  }

  /* ---------- 演出 ---------- */
  function run(n, ticket) {
    const cost = costOf(n);
    if (!ticket && S.data.coins < cost) { toast(`コインが足りません（あと ${fmt(cost - S.data.coins)}）。ステージをクリアしてミッション報酬を受け取ろう`, 'error', 3200); return; }
    const results = mode === 'char' ? pullChar(n, ticket) : pull(n, ticket);
    if (!results) return;
    sfx('gacha');
    showResults(n, results);
  }

  function showResults(n, results) {
    const best = results.reduce((b, r) => (S.RARITY[r.rarity].rank > S.RARITY[b].rank ? r.rarity : b), 'common');
    const ov = document.createElement('div');
    ov.className = `gacha-ov best-${best}`;
    ov.style.setProperty('--best', S.RARITY[best].color);
    ov.innerHTML = `
      <div class="gacha-ov-rays"></div>
      <div class="gacha-ov-chest">${A.chest('chest-art')}</div>
      <div class="gacha-flash"></div>
      <div class="gacha-results n${n === 1 ? 1 : 10}">
        ${results.map((r, i) => `<div class="res-card" style="--d:${i * 110}ms">
          ${r.kind === 'char' ? U.charCard(r.key, { isNew: r.isNew }) : U.itemCard(r.item, r.rarity, { isNew: r.isNew })}
          <div class="res-name">${esc(r.kind === 'char' ? C.CHARACTERS[r.key].name : C.ITEMS[r.item].name)}</div>
          ${U.rarityLabel(r.rarity)}
        </div>`).join('')}
      </div>
      <div class="gacha-ov-foot">
        <button class="btn btn-blue" id="g-again">もう一度（${n}回）</button>
        <button class="btn btn-yellow" id="g-ok">OK</button>
      </div>
      <p class="tap-skip">タップでスキップ</p>`;
    $('#app').appendChild(ov);

    const timers = [];
    const later = (fn, ms) => timers.push(setTimeout(fn, ms));
    const finish = () => { timers.forEach(clearTimeout); ov.classList.add('opened', 'revealed', 'done'); };
    requestAnimationFrame(() => ov.classList.add('show'));
    later(() => { ov.classList.add('opened'); sfx(S.RARITY[best].rank >= 3 ? 'gachaBig' : 'gachaOpen'); }, 1000);
    later(() => ov.classList.add('revealed'), 1450);
    later(() => ov.classList.add('done'), 1450 + results.length * 110 + 450);
    ov.addEventListener('click', (e) => { if (!ov.classList.contains('done') && !e.target.closest('button')) finish(); });

    const cost = costOf(n);
    const again = $('#g-again', ov);
    if (S.data.coins < cost) again.classList.add('short');
    again.addEventListener('click', () => {
      if (S.data.coins < cost) { toast(`コインが足りません（あと ${fmt(cost - S.data.coins)}）`, 'error'); return; }
      ov.remove(); run(n);
    });
    $('#g-ok', ov).addEventListener('click', () => { ov.classList.remove('show'); setTimeout(() => ov.remove(), 200); });

    const legend = results.filter((r) => r.rarity === 'legend').length;
    if (legend) later(() => toast(`レジェンド${results[0].kind === 'char' ? 'キャラ' : '装備'}を ${legend} 個ゲット！`, 'good', 3000), 1600);
  }

  DS.gacha = { render, update, pull, pullChar, rollRarity, rateTable, setMode };
})();
